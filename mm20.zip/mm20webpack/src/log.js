module.exports = {
    log(message) {
        console.log("LOG: " + message);
    }
}