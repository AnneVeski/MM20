<template>
  <button class="button is-primary">Click me!</button>
</template>

<script>
export default {

}
</script>

<style>

</style>