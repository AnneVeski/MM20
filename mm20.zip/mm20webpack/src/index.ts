let sometext:string = 'text';

function log(text: string):void {
    console.log(text);
}

log(sometext);